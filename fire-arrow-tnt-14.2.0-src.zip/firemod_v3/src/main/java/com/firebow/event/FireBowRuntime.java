package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    // Entity ID dedup
    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private static final long ARROW_DEDUP_MS = 3000L;

    // Position dedup
    private final Set<BlockPos> recentDone =
        Collections.newSetFromMap(new ConcurrentHashMap<>());

    // Vị trí được predict từ bow release — dùng bởi FireArrowMixin
    // Không có slot switch ở đây, chỉ lưu vị trí
    private volatile BlockPos precomputedRailPos = null;
    private volatile long     precomputedAtMs    = 0L;
    private static final long PRECOMPUTED_TTL_MS = 2000L;

    // Pending carts: pos → [ticksLeft, retryCount]
    private final Map<BlockPos, int[]> pendingCarts = new ConcurrentHashMap<>();
    private static final int MAX_RETRIES = 8;

    private final TickSynchronizer tickSync = new TickSynchronizer();
    private volatile boolean enabled = true;

    private FireBowRuntime() {}

    public boolean isEnabled()           { return enabled; }
    public void    toggle()              { enabled = !enabled; }

    /**
     * Bow release: lưu vị trí predict — không slot switch, không interrupt.
     * FireArrowMixin sẽ lấy vị trí này ngay tick đầu tiên tên xuất hiện.
     */
    public void storePrecomputedPos(BlockPos pos) {
        precomputedRailPos = pos;
        precomputedAtMs    = System.currentTimeMillis();
    }

    /**
     * FireArrowMixin gọi để lấy vị trí precomputed.
     * Trả về null nếu hết TTL hoặc không có.
     */
    public BlockPos getAndClearPrecomputed() {
        BlockPos pos = precomputedRailPos;
        if (pos == null) return null;
        if (System.currentTimeMillis() - precomputedAtMs > PRECOMPUTED_TTL_MS) {
            precomputedRailPos = null;
            return null;
        }
        precomputedRailPos = null;
        return pos;
    }

    public boolean isDuplicateArrow(int entityId) {
        Long last = acceptedArrows.get(entityId);
        return last != null && (System.currentTimeMillis() - last) < ARROW_DEDUP_MS;
    }

    public boolean wasRecentlyPlaced(BlockPos pos) {
        return recentDone.contains(pos);
    }

    /** Gọi từ FireArrowMixin sau khi đặt rail. */
    public void acceptArrow(int entityId, BlockPos railPos, int cartDelay) {
        if (recentDone.contains(railPos)) return;
        recentDone.add(railPos);
        acceptedArrows.put(entityId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> {
            acceptedArrows.remove(entityId);
            recentDone.remove(railPos);
        }, ARROW_DEDUP_MS);
        pendingCarts.put(railPos, new int[]{ cartDelay, 0 });
    }

    public void onClientTick(MinecraftClient client) {
        tickSync.onClientTick();
        if (pendingCarts.isEmpty()) return;
        if (client.player == null || client.world == null) return;
        if (!enabled) { pendingCarts.clear(); return; }

        Iterator<Map.Entry<BlockPos, int[]>> iter = pendingCarts.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<BlockPos, int[]> e = iter.next();
            BlockPos pos = e.getKey();
            int[] state  = e.getValue(); // [0]=ticksLeft [1]=retryCount

            state[0]--;
            if (state[0] > 0) continue;

            boolean hasRail =
                client.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                client.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (hasRail) {
                iter.remove();
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (!cart.isMissing() && client.interactionManager != null) {
                    int saved = client.player.getInventory().selectedSlot;
                    client.player.getInventory().selectedSlot = cart.slot;
                    InteractionUtil.placeOnTop(client, pos);
                    client.player.getInventory().selectedSlot = saved;
                }
            } else if (state[1] < MAX_RETRIES) {
                state[0] = 1;
                state[1]++;
            } else {
                iter.remove();
            }
        }
    }

    public void beforeSync() {
        // Chỉ dùng cho cart retry khi server lag — không switch slot khi đang draw
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (mc.player.isUsingItem()) return; // không interrupt bow draw

        // pendingCarts đã được xử lý trong onClientTick
        // beforeSync chỉ là safety net, không cần làm thêm gì
    }
}
